import React from "react";

export default function Error() {
  return (
    <div>
      Error page NOT Found lorem500
      <div className="bg-green-700 font-mono font-semibold ">hello you </div>
    </div>
  );
}
