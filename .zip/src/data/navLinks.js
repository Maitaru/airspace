export const navLinks = [
  {
    id: "100",
    text: "Home",
    url: "/",
  },
  {
    id: "101",
    text: "About Us",
    url: "/about",
  },
  {
    id: "102",
    text: "Listing",
    url: "/listing",
  },
  {
    id: "103",
    text: "Blog",
    url: "/blog",
  },
  {
    id: "104",
    text: "Contact Us",
    url: "/contact",
  },
];
