import estate_eating_table from "./estate_eating_table.jpg";
import estate_frontal from "./estate_frontal.jpg";
import estate_home2 from "./estate_home2.jpg";
import estate_home5 from "./estate_home5.jpg";
import estate_keys from "./estate_keys.jpg";
import estate_sky from "./estate_sky.jpg";

export {
  estate_eating_table,
  estate_frontal,
  estate_home2,
  estate_home5,
  estate_keys,
  estate_sky,
};


